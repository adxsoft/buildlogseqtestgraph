page-id:: 4d980b16-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: find scheduled blocks in a namespace
- blocks
    - *
- namespace
    - physics
- scheduled

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "find scheduled blocks in a namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(namespace ?page "physics")
[?block :block/scheduled ?scheduleddate]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "find scheduled blocks in a namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(namespace ?page "physics")
[?block :block/scheduled ?scheduleddate]
]
}
#+END_QUERY



### Links to other pages
[[Queries/queryexample001]]
