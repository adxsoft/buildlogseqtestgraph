page-id:: 4d96634c-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classH,classH,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Pay the energy bill

- LATER Dust the house furniture

- WAITING [[testpage015]] Post the bank letters

- CANCELLED Send email to the board

- CANCELLED Dust the house furniture

- WAITING [[testpage015]] Clean the roof gutters

- This is a single line in a block for page tech%2Fpython%2Fpythonpage002 
- This is a single line in a block 
### Links to other pages
[[tech/techpage008]]
