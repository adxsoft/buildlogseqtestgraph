page-id:: c5a719ba-504d-11ed-925f-705681b02121
pagetype:: p-advanced
tags:: classB,classD,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Check the water levels

- WAITING [[Queries/queryexample023]] Do the Shopping

- LATER Pay the energy bill

- CANCELLED Send email to the board

- This is a single line in a block for page testpage009 
- This is a multi line block
 in page testpage009 
with tag #tagE  
- This is a single line in a block for page testpage009 
- This is a single line in a block 
### Links to other pages
[[tech/techpage017]]
