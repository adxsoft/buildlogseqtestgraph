page-id:: 4d98461c-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: Pages only - access multiple property values
- pages
    - *
- pageproperties
    - pagetype, "p-minor"
    - pagetype, "p-major"

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "Pages only - access multiple property values"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
(page-property ?block :pagetype "p-minor")
(page-property ?block :pagetype "p-major")
)
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "Pages only - access multiple property values"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
(page-property ?block :pagetype "p-minor")
(page-property ?block :pagetype "p-major")
)
]
}
#+END_QUERY



### Links to other pages
[[Queries/queryexample030]]
