page-id:: 4d977868-5cc6-11ed-8e96-705681b02121
pagetype:: p-basic
tags:: classE,classF,classE

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[testpage015]] Pay the energy bill

- DONE Collect the fees from the club members

- This is a parent with two children blocks
   - Child 1 block with a tag #tagB 
   - category b-travel 
Child 2 block with a property 
- This is a single line in a block for page physics%2Ffluids%2Ffluidspage008 
- This is an indented list of items
    - Item A And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
        - Item A1 And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
        - Item A2 And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
    - Item B And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
    - Item C And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
        - Item C1 And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
    - Item D And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
 
- This is a single line in a block 
### Links to other pages
[[tech/python/pythonpage012]]
