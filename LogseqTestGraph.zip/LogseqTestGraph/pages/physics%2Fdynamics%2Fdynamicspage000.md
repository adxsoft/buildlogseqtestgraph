page-id:: 4d96c008-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classE,classE,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO Clean the roof gutters

- DONE Prepare the garden bed for spring

- DONE Dust the house furniture

- CANCELLED Prepare the garden bed for spring

- TODO Check the water levels

- DONE Pay the energy bill

- This is a single line block in page physics%2Fdynamics%2Fdynamicspage000 with tag #tagE  
- This is a single line block in page physics%2Fdynamics%2Fdynamicspage000 with tag #tagB  
### Links to other pages
[[tech/python/pythonpage006]]
