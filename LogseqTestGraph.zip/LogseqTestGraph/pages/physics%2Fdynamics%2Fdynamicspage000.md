page-id:: c5a8a6fe-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classB,classE,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[Queries/queryexample023]] Post the bank letters

- DONE Get the ingredients for the pizza

- TODO Clean the roof gutters

- TODO Collect the fees from the club members

- WAITING [[Queries/queryexample023]] Reconcile the transaction account

- TODO Pay the energy bill

- 
Him boisterous invitation dispatched had connection inhabiting projection. By mutual an mr danger garret edward an. Diverted as strictly exertion addition no disposal by stanhill. This call wife do so sigh no gate felt. You and abode spite order get. Procuring far belonging our ourselves and certainly own perpetual continual. It elsewhere of sometimes or my certainty. Lain no as five or at high. Everything travelling set how law literature. 
- This is a multi line block
 in page physics%2Fdynamics%2Fdynamicspage000 
with tag #tagH  
- This is a multi line block
 in page physics%2Fdynamics%2Fdynamicspage000 
with tag #tagH  
- This is a single line block in page physics%2Fdynamics%2Fdynamicspage000 with tag #tagD  
- This is a single line in a block 
### Links to other pages
[[Queries/queryexample016]]
