page-id:: c5a7fb82-504d-11ed-925f-705681b02121
pagetype:: p-advanced
tags:: classH,classC,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Get the ingredients for the pizza

- CANCELLED Dust the house furniture

- This is a single line block in page tech%2Ftechpage018 with tag #tagD  
- This is a single line in a block 
- This is a single line in a block 
- This is a single line block in page tech%2Ftechpage018 with tag #tagE  
### Links to other pages
[[tech/techpage010]]
