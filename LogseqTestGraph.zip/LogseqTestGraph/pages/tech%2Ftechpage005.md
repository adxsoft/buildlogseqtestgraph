page-id:: 4d95d594-5cc6-11ed-8e96-705681b02121
pagetype:: p-minor
tags:: classE,classC,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Clean the roof gutters

- DONE Prepare the garden bed for spring

- CANCELLED Collect the fees from the club members

- This is a single line block in page tech%2Ftechpage005 with tag #tagB  
- This is a single line in a block 
### Links to other pages
[[physics/dynamics/dynamicspage010]]
