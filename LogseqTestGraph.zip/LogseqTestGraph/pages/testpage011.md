page-id:: c5a727b6-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classC,classE,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO Check the water levels

- This is a parent with two children blocks
   - Child 1 block with a tag #tagC 
   - grade b-Alpha 
Child 2 block with a property 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - category b-Gamma 
Child 2 block with a property 
### Links to other pages
[[Queries/queryexample021]]
