page-id:: 4d95865c-5cc6-11ed-8e96-705681b02121
pagetype:: p-major
tags:: classG,classD,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[testpage015]] Dust the house furniture

- DONE Dust the house furniture

- DONE Reconcile the transaction account

- LATER Collect the fees from the club members

- WAITING [[testpage015]] Pay the energy bill

- LATER Pay the energy bill

- This is a single line block in page testpage011 with tag #tagH  
- This is a single line block in page testpage011 with tag #tagA  
- #tagG  In as name to here them deny wise this. As rapid woody my he me which. Men but they fail shew just wish next put. Led all visitor musical calling nor her. Within coming figure sex things are. Pretended concluded did repulsive education smallness yet yet described. Had country man his pressed shewing. No gate dare rose he.  
### Links to other pages
[[tech/techpage002]]
