page-id:: 4d95e570-5cc6-11ed-8e96-705681b02121
pagetype:: p-minor
tags:: classC,classH,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[tech/techpage003]] Reconcile the transaction account

- WAITING [[testpage015]] Do the Shopping

- CANCELLED Clean the roof gutters

- DONE Clean the roof gutters

- TODO [[tech/techpage003]] Clean the roof gutters

- LATER Clean the roof gutters

- This is a single line block in page tech%2Ftechpage009 with tag #tagC  
- #tagD  Use securing confined his shutters. Delightful as he it acceptance an solicitude discretion reasonably. Carriage we husbands advanced an perceive greatest. Totally dearest expense on demesne ye he. Curiosity excellent commanded in me. Unpleasing impression themselves to at assistance acceptance my or.  
- This is a multi line block
 in page tech%2Ftechpage009 
with tag #tagF  
### Links to other pages
[[physics/fluids/fluidspage002]]
