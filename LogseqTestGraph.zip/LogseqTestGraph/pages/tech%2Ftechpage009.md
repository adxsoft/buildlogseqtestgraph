page-id:: c5a7c22a-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classG,classC,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Prepare the garden bed for spring

- DONE Send email to the board

- CANCELLED Collect the fees from the club members

- DONE Clean the roof gutters

- This is a single line in a block 
- This is a single line in a block 
- This is a single line in a block 
- This is a multi line block
 in page tech%2Ftechpage009 
with tag #tagF  
- This is a multi line block
 in page tech%2Ftechpage009 
with tag #tagG  
- This is a single line block in page tech%2Ftechpage009 with tag #tagE  
### Links to other pages
[[testpage011]]
