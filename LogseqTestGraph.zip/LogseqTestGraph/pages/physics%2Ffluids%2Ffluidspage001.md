page-id:: 4d974528-5cc6-11ed-8e96-705681b02121
pagetype:: p-major
tags:: classD,classH,classD

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Do the Shopping

- DONE Post the bank letters

- DONE Do the Shopping

- LATER Pay the energy bill

- LATER Clean the roof gutters

- CANCELLED Dust the house furniture

- This is a multi line block
 in page physics%2Ffluids%2Ffluidspage001 
with tag #tagE  
- This is a single line block in page physics%2Ffluids%2Ffluidspage001 with tag #tagA  
### Links to other pages
[[tech/python/pythonpage014]]
