page-id:: c5aa0012-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
- journalsbetween
    - :today :30d-after
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?page :block/journal? true]
[?page :block/journal-day ?journaldate]
[(>= ?journaldate ?startdate)]
[(<= ?journaldate ?enddate)]
]
:inputs [:today :30d-after]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?page :block/journal? true]
[?page :block/journal-day ?journaldate]
[(>= ?journaldate ?startdate)]
[(<= ?journaldate ?enddate)]
]
:inputs [:today :30d-after]
}
#+END_QUERY

```

### Links to other pages
[[tech/python/pythonpage001]]
