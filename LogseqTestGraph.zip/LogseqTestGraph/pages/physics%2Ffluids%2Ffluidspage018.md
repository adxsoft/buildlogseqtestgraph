page-id:: c5a9cc50-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classH,classB,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Reconcile the transaction account

- LATER Reconcile the transaction account

- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - category b-fiction 
Child 2 block with a property 
- This is a multi line block
 in page physics%2Ffluids%2Ffluidspage018 
with tag #tagC  
- This is a single line in a block 
- This is a single line block in page physics%2Ffluids%2Ffluidspage018 with tag #tagA  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - category b-Gamma 
Child 2 block with a property 
### Links to other pages
[[tech/python/pythonpage016]]
