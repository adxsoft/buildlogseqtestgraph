page-id:: 4d96a1b8-5cc6-11ed-8e96-705681b02121
pagetype:: p-minor
tags:: classE,classE,classE

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[testpage015]] Get the ingredients for the pizza

- LATER Post the bank letters

- This is a parent with two children blocks
   - Child 1 block with a tag #tagG 
   - category b-Alpha 
Child 2 block with a property 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagF 
   - category b-Alpha 
Child 2 block with a property 
- This is a multi line block
 in page tech%2Fpython%2Fpythonpage014 
with tag #tagC  
- This is a single line in a block 
### Links to other pages
[[Queries/queryexample032]]
