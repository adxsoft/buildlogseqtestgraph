page-id:: 4d96e272-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classB,classE,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Post the bank letters

- DONE Collect the fees from the club members

- TODO Get the ingredients for the pizza

- LATER Post the bank letters

- DONE Send email to the board

- This is a parent with two children blocks
   - Child 1 block with a tag #tagG 
   - grade b-romance 
Child 2 block with a property 
### Links to other pages
[[Queries/queryexample010]]
