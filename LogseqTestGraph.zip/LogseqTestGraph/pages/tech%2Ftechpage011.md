page-id:: c5a7d382-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classE,classB,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[physics/dynamics/dynamicspage013]] Clean the roof gutters

- DONE Prepare the garden bed for spring

- This is a single line in a block 
- This is a single line block in page tech%2Ftechpage011 with tag #tagD  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - grade b-romance 
Child 2 block with a property 
### Links to other pages
[[physics/dynamics/dynamicspage014]]
