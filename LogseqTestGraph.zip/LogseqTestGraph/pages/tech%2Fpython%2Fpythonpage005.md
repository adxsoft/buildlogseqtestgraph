page-id:: c5a85370-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classH,classD,classD

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Check the water levels

- WAITING Get the ingredients for the pizza

- TODO Do the Shopping

- This is an indented list of items
    - Item A Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service.
        - Item A1 Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service.
        - Item A2 Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service.
    - Item B Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service.
    - Item C Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service.
        - Item C1 Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service.
    - Item D Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service.
 
- 
Admiration we surrounded possession frequently he. Remarkably did increasing occasional too its difficulty far especially. Known tiled but sorry joy balls. Bed sudden manner indeed fat now feebly. Face do with in need of wife paid that be. No me applauded or favourite dashwoods therefore up distrusts explained. 
- This is a multi line block
 in page tech%2Fpython%2Fpythonpage005 
with tag #tagF  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagA 
   - category b-Alpha 
Child 2 block with a property 
### Links to other pages
[[physics/fluids/fluidspage002]]
