page-id:: 4d95e192-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classB,classD,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Post the bank letters

- WAITING [[testpage015]] Collect the fees from the club members

- LATER Collect the fees from the club members

- LATER Send email to the board

- DONE Dust the house furniture

- CANCELLED Dust the house furniture

- This is a single line in a block for page tech%2Ftechpage008 
- This is a single line block in page tech%2Ftechpage008 with tag #tagE  
### Links to other pages
[[Queries/queryexample021]]
