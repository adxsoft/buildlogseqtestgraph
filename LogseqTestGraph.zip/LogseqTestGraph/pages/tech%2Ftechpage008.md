page-id:: c5a7bf1e-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classE,classH,classE

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Get the ingredients for the pizza

- TODO Do the Shopping

- TODO Dust the house furniture

- CANCELLED Do the Shopping

- LATER Dust the house furniture

- DONE Collect the fees from the club members

- This is a single line block in page tech%2Ftechpage008 with tag #tagB  
### Links to other pages
[[Queries/queryexample009]]
