page-id:: c5a84858-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classA,classD,classD

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[physics/dynamics/dynamicspage013]] Get the ingredients for the pizza

- LATER Clean the roof gutters

- CANCELLED Prepare the garden bed for spring

- LATER Get the ingredients for the pizza

- DONE Collect the fees from the club members

- designation:: b-romance
 Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery. 
- designation:: b-non-fiction
 Engrossed suffering supposing he recommend do eagerness. Commanded no of depending extremity recommend attention tolerably. Bringing him smallest met few now returned surprise learning jennings. Objection delivered eagerness he exquisite at do in. Warmly up he nearer mr merely me. 
- This is a single line in a block 
- This is a single line in a block 
- This is a single line in a block for page tech%2Fpython%2Fpythonpage003 
- This is a single line in a block for page tech%2Fpython%2Fpythonpage003 
### Links to other pages
[[testpage007]]
