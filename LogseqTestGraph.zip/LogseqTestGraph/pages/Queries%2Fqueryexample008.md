page-id:: c5a9e4e2-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: blocktags and pages example
- pages
    - testpage00*
- blocktags
    - tagA
    - not tagB
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "blocktags and pages example"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
(page-ref ?block "tagA")
(not (page-ref ?block "tagB"))
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "blocktags and pages example"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
(page-ref ?block "tagA")
(not (page-ref ?block "tagB"))
]
}
#+END_QUERY

```

### Links to other pages
[[Queries/queryexample002]]
