page-id:: c5a94438-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classF,classE,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[physics/dynamics/dynamicspage013]] Send email to the board

- DONE Dust the house furniture

- TODO [[physics/dynamics/dynamicspage013]] Check the water levels

- TODO [[physics/dynamics/dynamicspage013]] Clean the roof gutters

- CANCELLED Pay the energy bill

- DONE Send email to the board

- This is a single line block in page physics%2Ffluids%2Ffluidspage003 with tag #tagC  
### Links to other pages
[[testpage017]]
