page-id:: c5a7e944-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classH,classF,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING Collect the fees from the club members

- WAITING Dust the house furniture

- TODO Reconcile the transaction account

- This is a single line in a block 
- #tagG  Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service. 
- This is a single line block in page tech%2Ftechpage015 with tag #tagF  
### Links to other pages
[[Queries/queryexample009]]
