page-id:: 4d96014a-5cc6-11ed-8e96-705681b02121
pagetype:: p-minor
tags:: classF,classF,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[tech/techpage003]] Get the ingredients for the pizza

- CANCELLED Reconcile the transaction account

- TODO [[tech/techpage003]] Reconcile the transaction account

- DONE Clean the roof gutters

- DONE Send email to the board

- WAITING [[testpage015]] Get the ingredients for the pizza

- This is an indented list of items
    - Item A Months on ye at by esteem desire warmth former. 
        - Item A1 Months on ye at by esteem desire warmth former. 
        - Item A2 Months on ye at by esteem desire warmth former. 
    - Item B Months on ye at by esteem desire warmth former. 
    - Item C Months on ye at by esteem desire warmth former. 
        - Item C1 Months on ye at by esteem desire warmth former. 
    - Item D Months on ye at by esteem desire warmth former. 
 
- #tagG  Denote simple fat denied add worthy little use. As some he so high down am week. Conduct esteems by cottage to pasture we winding. On assistance he cultivated considered frequently. Person how having tended direct own day man. Saw sufficient indulgence one own you inquietude sympathize. 
- This is a single line in a block 
- This is a single line in a block 
- This is a single line block in page tech%2Ftechpage015 with tag #tagC  
- This is a single line in a block 
### Links to other pages
[[tech/techpage013]]
