page-id:: c5a9672e-504d-11ed-925f-705681b02121
pagetype:: p-advanced
tags:: classE,classD,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Pay the energy bill

- TODO Dust the house furniture

- WAITING Prepare the garden bed for spring

- TODO Dust the house furniture

- 
Maids table how learn drift but purse stand yet set. Music me house could among oh as their. Piqued our sister shy nature almost his wicket. Hand dear so we hour to. He we be hastily offence effects he service. 
- This is a single line in a block for page physics%2Ffluids%2Ffluidspage007 
- designation:: b-non-fiction
 Eyes year if miss he as upon. 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagB 
   - designation b-Alpha 
Child 2 block with a property 
- This is a single line block in page physics%2Ffluids%2Ffluidspage007 with tag #tagC  
### Links to other pages
[[physics/fluids/fluidspage015]]
