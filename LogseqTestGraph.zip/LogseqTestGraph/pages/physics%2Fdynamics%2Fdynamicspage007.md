page-id:: c5a8e0ce-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classG,classF,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Clean the roof gutters

- WAITING [[Queries/queryexample023]] Prepare the garden bed for spring

- CANCELLED Do the Shopping

- This is a parent with two children blocks
   - Child 1 block with a tag #tagH 
   - grade b-fiction 
Child 2 block with a property 
### Links to other pages
[[tech/techpage008]]
