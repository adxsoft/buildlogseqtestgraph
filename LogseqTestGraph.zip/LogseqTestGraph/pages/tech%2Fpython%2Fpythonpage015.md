page-id:: c5a88b7e-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classB,classF,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Do the Shopping

- CANCELLED Get the ingredients for the pizza

- WAITING [[Queries/queryexample023]] Send email to the board

- #tagF  To sorry world an at do spoil along. Incommode he depending do frankness remainder to. Edward day almost active him friend thirty piqued. People as period twenty my extent as. Set was better abroad ham plenty secure had horses. Admiration has sir decisively excellence say everything inhabiting acceptance. Sooner settle add put you sudden him. 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagE 
   - category b-romance 
Child 2 block with a property 
- 
In by an appetite no humoured returned informed. Possession so comparison inquietude he he conviction no decisively. 
- This is a multi line block
 in page tech%2Fpython%2Fpythonpage015 
with tag #tagD  
- #tagH  Eyes year if miss he as upon. 
### Links to other pages
[[testpage010]]
