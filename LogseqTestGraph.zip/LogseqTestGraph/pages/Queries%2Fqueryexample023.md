page-id:: 4d98243e-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: find journals between dates
- blocks
    - *
- journalsbetween
    - :30d-before :today

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "find journals between dates"]
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?page :block/journal-day ?journaldate]
[(>= ?journaldate ?startdate)]
[(<= ?journaldate ?enddate)]
]
:inputs [:30d-before :today]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "find journals between dates"]
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?page :block/journal-day ?journaldate]
[(>= ?journaldate ?startdate)]
[(<= ?journaldate ?enddate)]
]
:inputs [:30d-before :today]
}
#+END_QUERY



### Links to other pages
[[tech/python/pythonpage000]]
