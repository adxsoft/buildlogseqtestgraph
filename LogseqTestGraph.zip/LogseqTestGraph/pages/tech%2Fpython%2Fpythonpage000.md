page-id:: c5a8280a-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classG,classE,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Dust the house furniture

- CANCELLED Pay the energy bill

- This is a single line in a block for page tech%2Fpython%2Fpythonpage000 
- This is a single line block in page tech%2Fpython%2Fpythonpage000 with tag #tagF  
### Links to other pages
[[tech/python/pythonpage011]]
