page-id:: 4d965474-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classA,classE,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Check the water levels

- LATER Dust the house furniture

- WAITING Collect the fees from the club members

- LATER Do the Shopping

- DONE Dust the house furniture

- CANCELLED Dust the house furniture

- This is a single line block in page tech%2Fpython%2Fpythonpage000 with tag #tagD  
### Links to other pages
[[physics/fluids/fluidspage017]]
