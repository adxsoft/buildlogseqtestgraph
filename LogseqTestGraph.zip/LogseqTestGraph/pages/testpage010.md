page-id:: c5a71f28-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classF,classD,classD

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Pay the energy bill

- TODO Do the Shopping

- DONE Send email to the board

- This is a parent with two children blocks
   - Child 1 block with a tag #tagF 
   - designation b-Gamma 
Child 2 block with a property 
- This is an indented list of items
    - Item A Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
        - Item A1 Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
        - Item A2 Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
    - Item B Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
    - Item C Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
        - Item C1 Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
    - Item D Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - designation b-fiction 
Child 2 block with a property 
- This is a multi line block
 in page testpage010 
with tag #tagG  
### Links to other pages
[[tech/python/pythonpage002]]
