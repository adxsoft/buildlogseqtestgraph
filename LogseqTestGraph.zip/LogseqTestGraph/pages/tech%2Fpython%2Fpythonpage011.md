page-id:: 4d969358-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classC,classA,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO Dust the house furniture

- LATER Check the water levels

- CANCELLED Pay the energy bill

- DONE Reconcile the transaction account

- WAITING Post the bank letters

- This is a single line in a block 
- This is a single line in a block 
- This is a single line in a block 
- #tagA  Park gate sell they west hard for the. Abode stuff noisy manor blush yet the far. Up colonel so between removed so do. Years use place decay sex worth drift age. Men lasting out end article express fortune demands own charmed. About are are money ask how seven. 
### Links to other pages
[[Queries/queryexample026]]
