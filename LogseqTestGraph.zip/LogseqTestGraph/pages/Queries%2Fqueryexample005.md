page-id:: c5a9e208-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pages command - ignore pages (including wildcards)
- pages
    - not testpage*
    - not Queries*
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - ignore pages (including wildcards)"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(not [(clojure.string/starts-with? ?pagename "testpage")])
(not [(clojure.string/starts-with? ?pagename "Queries")])
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - ignore pages (including wildcards)"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(not [(clojure.string/starts-with? ?pagename "testpage")])
(not [(clojure.string/starts-with? ?pagename "Queries")])
]
}
#+END_QUERY

```

### Links to other pages
[[tech/python/pythonpage011]]
