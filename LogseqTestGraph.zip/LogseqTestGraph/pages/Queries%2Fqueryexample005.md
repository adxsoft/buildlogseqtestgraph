page-id:: 4d97d6d2-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pages command - ignore pages (including wildcards)
- pages
    - not testpage*
    - not Queries*

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - ignore pages (including wildcards)"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
(not [(clojure.string/starts-with? ?pagename "testpage")])
(not [(clojure.string/starts-with? ?pagename "Queries")])
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - ignore pages (including wildcards)"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
(not [(clojure.string/starts-with? ?pagename "testpage")])
(not [(clojure.string/starts-with? ?pagename "Queries")])
]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage011]]
