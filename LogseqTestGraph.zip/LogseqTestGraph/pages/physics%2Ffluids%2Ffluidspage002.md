page-id:: c5a94000-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classE,classH,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Dust the house furniture

- WAITING [[Queries/queryexample023]] Reconcile the transaction account

- TODO Dust the house furniture

- WAITING [[Queries/queryexample023]] Do the Shopping

- TODO Get the ingredients for the pizza

- CANCELLED Collect the fees from the club members

- 
Extremity as if breakfast agreement. Off now mistress provided out horrible opinions. Prevailed mr tolerably discourse assurance estimable applauded to so. Him everything melancholy uncommonly but solicitude inhabiting projection off. Connection stimulated estimating excellence an to impression. 
### Links to other pages
[[tech/python/pythonpage015]]
