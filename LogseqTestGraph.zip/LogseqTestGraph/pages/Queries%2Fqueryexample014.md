page-id:: c5a9f34c-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: select and exclude blocks with block properties
- blockproperties
    - category, "b-thriller"
    - category, "b-western"
    - grade "b-fiction"
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "select and exclude blocks with block properties"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
(property ?block :category "b-thriller")
(property ?block :category "b-western")
(property ?block :grade "b-fiction" $$ARG2)
)
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "select and exclude blocks with block properties"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
(property ?block :category "b-thriller")
(property ?block :category "b-western")
(property ?block :grade "b-fiction" $$ARG2)
)
]
}
#+END_QUERY

```

### Links to other pages
[[Queries/queryexample027]]
