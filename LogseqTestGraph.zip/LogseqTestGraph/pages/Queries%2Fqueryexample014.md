page-id:: 4d97fe50-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: select and exclude blocks with block properties
- blocks
    - *
- blockproperties
    - category, "b-thriller"
    - category, "b-western"
    - grade, "b-fiction"

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "select and exclude blocks with block properties"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
(property ?block :category "b-thriller")
(property ?block :category "b-western")
(property ?block :grade "b-fiction")
)
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "select and exclude blocks with block properties"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
(property ?block :category "b-thriller")
(property ?block :category "b-western")
(property ?block :grade "b-fiction")
)
]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage007]]
