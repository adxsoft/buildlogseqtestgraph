page-id:: 4d984ec8-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: Pages only - select all pages
- pages
    - *

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "Pages only - select all pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "Pages only - select all pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage014]]
