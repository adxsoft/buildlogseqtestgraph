page-id:: 4d969e48-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classD,classC,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Check the water levels

- LATER Send email to the board

- LATER Get the ingredients for the pizza

- LATER Do the Shopping

- WAITING Send email to the board

- This is a single line block in page tech%2Fpython%2Fpythonpage013 with tag #tagB  
- This is a multi line block
 in page tech%2Fpython%2Fpythonpage013 
with tag #tagE  
### Links to other pages
[[Queries/queryexample002]]
