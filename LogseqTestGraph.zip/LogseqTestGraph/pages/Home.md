This is the home page of the automatically generated logseq graph

- [[Graph Statistics]]

- [[Query Testing]]

- ## Links to Task Pages
   - [[TODO]]
[[WAITING]]
[[DONE]]
[[CANCELLED]]


- ### Pages Generated for prefix=testpage and  namespace=none

[[testpage000]]
[[testpage001]]
[[testpage002]]
[[testpage003]]
[[testpage004]]
[[testpage005]]
[[testpage006]]
[[testpage007]]
[[testpage008]]
[[testpage009]]
[[testpage010]]
[[testpage011]]
[[testpage012]]
[[testpage013]]
[[testpage014]]
[[testpage015]]
[[testpage016]]
[[testpage017]]
[[testpage018]]
[[testpage019]]

- ### Pages Generated for prefix=techpage and  namespace=tech/

[[tech/techpage000]]
[[tech/techpage001]]
[[tech/techpage002]]
[[tech/techpage003]]
[[tech/techpage004]]
[[tech/techpage005]]
[[tech/techpage006]]
[[tech/techpage007]]
[[tech/techpage008]]
[[tech/techpage009]]
[[tech/techpage010]]
[[tech/techpage011]]
[[tech/techpage012]]
[[tech/techpage013]]
[[tech/techpage014]]
[[tech/techpage015]]
[[tech/techpage016]]
[[tech/techpage017]]
[[tech/techpage018]]
[[tech/techpage019]]

- ### Pages Generated for prefix=pythonpage and  namespace=tech/python/

[[tech/python/pythonpage000]]
[[tech/python/pythonpage001]]
[[tech/python/pythonpage002]]
[[tech/python/pythonpage003]]
[[tech/python/pythonpage004]]
[[tech/python/pythonpage005]]
[[tech/python/pythonpage006]]
[[tech/python/pythonpage007]]
[[tech/python/pythonpage008]]
[[tech/python/pythonpage009]]
[[tech/python/pythonpage010]]
[[tech/python/pythonpage011]]
[[tech/python/pythonpage012]]
[[tech/python/pythonpage013]]
[[tech/python/pythonpage014]]
[[tech/python/pythonpage015]]
[[tech/python/pythonpage016]]
[[tech/python/pythonpage017]]
[[tech/python/pythonpage018]]
[[tech/python/pythonpage019]]

- ### Pages Generated for prefix=dynamicspage and  namespace=physics/dynamics/

[[physics/dynamics/dynamicspage000]]
[[physics/dynamics/dynamicspage001]]
[[physics/dynamics/dynamicspage002]]
[[physics/dynamics/dynamicspage003]]
[[physics/dynamics/dynamicspage004]]
[[physics/dynamics/dynamicspage005]]
[[physics/dynamics/dynamicspage006]]
[[physics/dynamics/dynamicspage007]]
[[physics/dynamics/dynamicspage008]]
[[physics/dynamics/dynamicspage009]]
[[physics/dynamics/dynamicspage010]]
[[physics/dynamics/dynamicspage011]]
[[physics/dynamics/dynamicspage012]]
[[physics/dynamics/dynamicspage013]]
[[physics/dynamics/dynamicspage014]]
[[physics/dynamics/dynamicspage015]]
[[physics/dynamics/dynamicspage016]]
[[physics/dynamics/dynamicspage017]]
[[physics/dynamics/dynamicspage018]]
[[physics/dynamics/dynamicspage019]]

- ### Pages Generated for prefix=fluidspage and  namespace=physics/fluids/

[[physics/fluids/fluidspage000]]
[[physics/fluids/fluidspage001]]
[[physics/fluids/fluidspage002]]
[[physics/fluids/fluidspage003]]
[[physics/fluids/fluidspage004]]
[[physics/fluids/fluidspage005]]
[[physics/fluids/fluidspage006]]
[[physics/fluids/fluidspage007]]
[[physics/fluids/fluidspage008]]
[[physics/fluids/fluidspage009]]
[[physics/fluids/fluidspage010]]
[[physics/fluids/fluidspage011]]
[[physics/fluids/fluidspage012]]
[[physics/fluids/fluidspage013]]
[[physics/fluids/fluidspage014]]
[[physics/fluids/fluidspage015]]
[[physics/fluids/fluidspage016]]
[[physics/fluids/fluidspage017]]
[[physics/fluids/fluidspage018]]
[[physics/fluids/fluidspage019]]


## Query Example Pages Generated

Query [[Queries/queryexample000]] - pages command - select all pages
Query [[Queries/queryexample001]] - pages command - specific pages
Query [[Queries/queryexample002]] - pages command - pages by wildcards
Query [[Queries/queryexample003]] - pages command - pages by wildcards
Query [[Queries/queryexample004]] - pages command - pages by wildcards
Query [[Queries/queryexample005]] - pages command - ignore pages (including wildcards)
Query [[Queries/queryexample006]] - blocks command - ignore blocks using wildcards
Query [[Queries/queryexample007]] - blocktags - select and exclude block level tags
Query [[Queries/queryexample008]] - blocktags and pages don't mix
Query [[Queries/queryexample009]] - pagetags - page level tags
Query [[Queries/queryexample010]] - pagetags and pages
Query [[Queries/queryexample011]] - select and exclude task types
Query [[Queries/queryexample012]] - select and exclude task types
Query [[Queries/queryexample013]] - select and exclude pages with page properties
Query [[Queries/queryexample014]] - select and exclude blocks with block properties
Query [[Queries/queryexample015]] - only search pages in specific namespace
Query [[Queries/queryexample016]] - find block properties in a namespace
Query [[Queries/queryexample017]] - find scheduled blocks in a namespace
Query [[Queries/queryexample018]] - scheduled - find scheduled blocks in a date range
Query [[Queries/queryexample019]] - find blocks with deadlines
Query [[Queries/queryexample020]] - find blocks with deadlines in a date range
Query [[Queries/queryexample021]] - find journals
Query [[Queries/queryexample022]] - find journal in a date range
Query [[Queries/queryexample023]] - find journals between dates
Query [[Queries/queryexample024]] - collapse results
Query [[Queries/queryexample025]] - expand results
Query [[Queries/queryexample026]] - show breadcrumbs
Query [[Queries/queryexample027]] - hide breadcrumbs
Query [[Queries/queryexample028]] - find journal in a date range using blocks
Query [[Queries/queryexample029]] - All blocks - test access to parent pages tags, journal
Query [[Queries/queryexample030]] - Pages only - Access page properties
Query [[Queries/queryexample031]] - Pages only - access multiple property values
Query [[Queries/queryexample032]] - Page blocks only - pagetags
Query [[Queries/queryexample033]] - Pages only - select all pages
Query [[Queries/queryexample034]] - pages command - specific pages
Query [[Queries/queryexample035]] - pages command - pages by wildcards
Query [[Queries/queryexample036]] - pages command - pages by wildcards
Query [[Queries/queryexample037]] - journalsbetween defaulting to blocks retrieval
Query [[Queries/queryexample038]] - journalsbetween using pages retrieval

- ## Journals Generated

[[Jan 1st, 2020]]
[[Jan 16th, 2020]]
[[Feb 28th, 2020]]
[[Mar 8th, 2020]]
[[Apr 5th, 2020]]
[[Apr 16th, 2020]]
[[May 15th, 2020]]
[[Jun 11th, 2020]]
[[Jun 16th, 2020]]
[[Jul 19th, 2020]]
[[Jul 27th, 2020]]
[[Aug 10th, 2020]]
[[Sep 21st, 2020]]
[[Oct 31st, 2020]]
[[Nov 16th, 2020]]
[[Nov 24th, 2020]]
[[Dec 17th, 2020]]
[[Jan 23rd, 2021]]
[[Mar 6th, 2021]]
[[Apr 13th, 2021]]
