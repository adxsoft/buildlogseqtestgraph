page-id:: 4d96ab18-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classB,classE,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO Collect the fees from the club members

- TODO Prepare the garden bed for spring

- CANCELLED Get the ingredients for the pizza

- CANCELLED Pay the energy bill

- CANCELLED Pay the energy bill

- WAITING Dust the house furniture

- This is a multi line block
 in page tech%2Fpython%2Fpythonpage016 
with tag #tagB  
- designation:: b-thriller
 Marianne jointure attended she hastened surprise but she. Ever lady son yet you very paid form away. He advantage of exquisite resolving if on tolerably. Become sister on in garden it barton waited on. 
### Links to other pages
[[physics/fluids/fluidspage001]]
