page-id:: c5a8924a-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classE,classE,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING [[Queries/queryexample023]] Get the ingredients for the pizza

- DONE Clean the roof gutters

- LATER Reconcile the transaction account

- This is a single line in a block 
- This is a multi line block
 in page tech%2Fpython%2Fpythonpage016 
with tag #tagB  
- #tagC  And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we.  
- #tagE  Use securing confined his shutters. Delightful as he it acceptance an solicitude discretion reasonably. Carriage we husbands advanced an perceive greatest. Totally dearest expense on demesne ye he. Curiosity excellent commanded in me. Unpleasing impression themselves to at assistance acceptance my or.  
- category:: b-Gamma
 Two assure edward whence the was. Who worthy yet ten boy denote wonder. Weeks views her sight old tears sorry. Additions can suspected its concealed put furnished. Met the why particular devonshire decisively considered partiality. Certain it waiting no entered is. Passed her indeed uneasy shy polite appear denied. Oh less girl no walk. At he spot with five of view. 
### Links to other pages
[[Queries/queryexample006]]
