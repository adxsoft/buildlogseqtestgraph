page-id:: c5a9e050-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - testpage00*
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
}
#+END_QUERY

```

- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - *002
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/ends-with? ?pagename "002")]
]
}
#+END_QUERY

```

- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - *page00*
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/includes? ?pagename "page00")]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/includes? ?pagename "page00")]
]
}
#+END_QUERY

```

### Links to other pages
[[physics/fluids/fluidspage010]]
