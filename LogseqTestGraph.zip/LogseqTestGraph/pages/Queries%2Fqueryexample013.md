page-id:: 4d97f9fa-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: select and exclude pages with page properties
- pages
    - *
- pageproperties
    - pagetype, "p-major"
    - pagetype, "p-minor"
    - not pagetype, "p-advanced"

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "select and exclude pages with page properties"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
(page-property ?block :pagetype "p-major")
(page-property ?block :pagetype "p-minor")
)
(not (page-property ?block :pagetype "p-advanced"))
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "select and exclude pages with page properties"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
( or 
(page-property ?block :pagetype "p-major")
(page-property ?block :pagetype "p-minor")
)
(not (page-property ?block :pagetype "p-advanced"))
]
}
#+END_QUERY



### Links to other pages
[[tech/python/pythonpage016]]
