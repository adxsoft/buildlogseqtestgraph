page-id:: 4d9841ee-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: Pages only - Access page properties
- pages
    - *
- pageproperties
    - pagetype, "p-minor"

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "Pages only - Access page properties"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
(page-property ?block :pagetype "p-minor")
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "Pages only - Access page properties"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
(page-property ?block :pagetype "p-minor")
]
}
#+END_QUERY



### Links to other pages
[[tech/techpage009]]
