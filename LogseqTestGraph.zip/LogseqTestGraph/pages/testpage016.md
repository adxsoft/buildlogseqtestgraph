page-id:: c5a75d94-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classG,classE,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Do the Shopping

- WAITING [[Queries/queryexample023]] Prepare the garden bed for spring

- WAITING [[Queries/queryexample023]] Clean the roof gutters

- DONE Reconcile the transaction account

- TODO Post the bank letters

- 
Months on ye at by esteem desire warmth former.  
- This is a multi line block
 in page testpage016 
with tag #tagA  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagH 
   - category b-Beta 
Child 2 block with a property 
### Links to other pages
[[tech/python/pythonpage018]]
