page-id:: 4d959ef8-5cc6-11ed-8e96-705681b02121
pagetype:: p-basic
tags:: classA,classD,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Collect the fees from the club members

- DONE Collect the fees from the club members

- CANCELLED Do the Shopping

- DONE Clean the roof gutters

- LATER Post the bank letters

- LATER Send email to the board

- This is a single line in a block 
### Links to other pages
[[tech/techpage007]]
