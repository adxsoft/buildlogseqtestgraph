page-id:: 4d95b73a-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classG,classD,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Check the water levels

- WAITING [[testpage015]] Send email to the board

- WAITING [[testpage015]] Pay the energy bill

- CANCELLED Do the Shopping

- This is a parent with two children blocks
   - Child 1 block with a tag #tagH 
   - category b-fiction 
Child 2 block with a property 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagF 
   - grade b-travel 
Child 2 block with a property 
- #tagG  Him boisterous invitation dispatched had connection inhabiting projection. By mutual an mr danger garret edward an. Diverted as strictly exertion addition no disposal by stanhill. This call wife do so sigh no gate felt. You and abode spite order get. Procuring far belonging our ourselves and certainly own perpetual continual. It elsewhere of sometimes or my certainty. Lain no as five or at high. Everything travelling set how law literature. 
- This is a single line in a block 
### Links to other pages
[[Queries/queryexample014]]
