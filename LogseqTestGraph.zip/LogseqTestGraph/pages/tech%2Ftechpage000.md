page-id:: c5a78c60-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classH,classB,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO Get the ingredients for the pizza

- LATER Do the Shopping

- This is a multi line block
 in page tech%2Ftechpage000 
with tag #tagC  
- This is a single line in a block 
- This is an indented list of items
    - Item A Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.
        - Item A1 Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.
        - Item A2 Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.
    - Item B Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.
    - Item C Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.
        - Item C1 Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.
    - Item D Delightful unreserved impossible few estimating men favourable see entreaties. She propriety immediate was improving. He or entrance humoured likewise moderate. Much nor game son say feel. Fat make met can must form into gate. Me we offending prevailed discovery.
 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagA 
   - designation b-Gamma 
Child 2 block with a property 
- This is a single line block in page tech%2Ftechpage000 with tag #tagB  
### Links to other pages
[[Queries/queryexample021]]
