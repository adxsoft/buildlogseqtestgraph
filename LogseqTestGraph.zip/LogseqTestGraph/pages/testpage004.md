page-id:: c5a6f08e-504d-11ed-925f-705681b02121
pagetype:: p-advanced
tags:: classC,classD,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Clean the roof gutters

- CANCELLED Clean the roof gutters

- WAITING Clean the roof gutters

- WAITING Pay the energy bill

- CANCELLED Prepare the garden bed for spring

- This is an indented list of items
    - Item A On consider laughter civility offended oh.
        - Item A1 On consider laughter civility offended oh.
        - Item A2 On consider laughter civility offended oh.
    - Item B On consider laughter civility offended oh.
    - Item C On consider laughter civility offended oh.
        - Item C1 On consider laughter civility offended oh.
    - Item D On consider laughter civility offended oh.
 
### Links to other pages
[[tech/python/pythonpage014]]
