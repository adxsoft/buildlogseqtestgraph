page-id:: c5a8614e-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classB,classH,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO Post the bank letters

- TODO Get the ingredients for the pizza

- WAITING [[Queries/queryexample023]] Get the ingredients for the pizza

- DONE Get the ingredients for the pizza

- This is a parent with two children blocks
   - Child 1 block with a tag #tagH 
   - grade b-Gamma 
Child 2 block with a property 
### Links to other pages
[[Queries/queryexample018]]
