page-id:: 4d979334-5cc6-11ed-8e96-705681b02121
pagetype:: p-major
tags:: classA,classC,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING Do the Shopping

- LATER Do the Shopping

- CANCELLED Get the ingredients for the pizza

- WAITING Clean the roof gutters

- TODO [[tech/techpage003]] Pay the energy bill

- CANCELLED Pay the energy bill

- This is a multi line block
 in page physics%2Ffluids%2Ffluidspage012 
with tag #tagE  
- This is a single line in a block for page physics%2Ffluids%2Ffluidspage012 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagG 
   - category b-fiction 
Child 2 block with a property 
- This is a single line block in page physics%2Ffluids%2Ffluidspage012 with tag #tagA  
### Links to other pages
[[Queries/queryexample029]]
