page-id:: 4d970cca-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classC,classA,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Reconcile the transaction account

- CANCELLED Send email to the board

- DONE Collect the fees from the club members

- LATER Check the water levels

- This is a multi line block
 in page physics%2Fdynamics%2Fdynamicspage013 
with tag #tagH  
- This is an indented list of items
    - Item A And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
        - Item A1 And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
        - Item A2 And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
    - Item B And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
    - Item C And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
        - Item C1 And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
    - Item D And sir dare view but over man. So at within mr to simple assure. Mr disposing continued it offending arranging in we. 
 
### Links to other pages
[[Queries/queryexample015]]
