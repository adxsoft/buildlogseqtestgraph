page-id:: 4d95bd2a-5cc6-11ed-8e96-705681b02121
pagetype:: p-minor
tags:: classH,classE,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Check the water levels

- LATER Pay the energy bill

- LATER Post the bank letters

- DONE Send email to the board

- TODO [[tech/techpage003]] Clean the roof gutters

- WAITING Do the Shopping

- This is a parent with two children blocks
   - Child 1 block with a tag #tagB 
   - grade b-Gamma 
Child 2 block with a property 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagB 
   - designation b-thriller 
Child 2 block with a property 
- This is a multi line block
 in page tech%2Ftechpage001 
with tag #tagG  
- This is a single line in a block 
- This is a single line block in page tech%2Ftechpage001 with tag #tagF  
### Links to other pages
[[physics/fluids/fluidspage006]]
