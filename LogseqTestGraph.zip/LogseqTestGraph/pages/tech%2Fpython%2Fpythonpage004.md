page-id:: c5a850c8-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classH,classH,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Get the ingredients for the pizza

- DONE Send email to the board

- TODO Dust the house furniture

- category:: b-travel
 On consider laughter civility offended oh. 
### Links to other pages
[[physics/dynamics/dynamicspage006]]
