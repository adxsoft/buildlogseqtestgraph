page-id:: c5a9de34-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pages command - specific pages
- pages
    - testpage001
    - testpage002
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - specific pages"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
[?page :block/name "testpage001"]
[?page :block/name "testpage002"]
)
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - specific pages"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
[?page :block/name "testpage001"]
[?page :block/name "testpage002"]
)
]
}
#+END_QUERY

```

### Links to other pages
[[tech/techpage014]]
