page-id:: c5a6dd74-504d-11ed-925f-705681b02121
pagetype:: p-advanced
tags:: classC,classG,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO Send email to the board

- TODO Dust the house furniture

- LATER Pay the energy bill

- LATER Get the ingredients for the pizza

- CANCELLED Send email to the board

- WAITING [[Queries/queryexample023]] Collect the fees from the club members

- This is a single line in a block for page testpage002 
- This is a multi line block
 in page testpage002 
with tag #tagC  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagA 
   - grade b-Beta 
Child 2 block with a property 
### Links to other pages
[[Queries/queryexample008]]
