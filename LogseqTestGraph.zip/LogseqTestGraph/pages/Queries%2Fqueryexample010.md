page-id:: c5a9e8ca-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pagetags and pages
- pages
    - *dynamics*
- pagetags
    - p-major
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pagetags and pages"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/includes? ?pagename "dynamics")]
(page-tags ?page #{"p-major"})
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pagetags and pages"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/includes? ?pagename "dynamics")]
(page-tags ?page #{"p-major"})
]
}
#+END_QUERY

```

### Links to other pages
[[testpage011]]
