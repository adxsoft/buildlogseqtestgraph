page-id:: 4d96fe74-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classF,classF,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Dust the house furniture

- DONE Prepare the garden bed for spring

- CANCELLED Reconcile the transaction account

- TODO Prepare the garden bed for spring

- WAITING [[testpage015]] Send email to the board

- LATER Prepare the garden bed for spring

- This is a parent with two children blocks
   - Child 1 block with a tag #tagC 
   - category b-fiction 
Child 2 block with a property 
- This is an indented list of items
    - Item A Article evident arrived express highest men did boy. 
        - Item A1 Article evident arrived express highest men did boy. 
        - Item A2 Article evident arrived express highest men did boy. 
    - Item B Article evident arrived express highest men did boy. 
    - Item C Article evident arrived express highest men did boy. 
        - Item C1 Article evident arrived express highest men did boy. 
    - Item D Article evident arrived express highest men did boy. 
 
- This is a single line in a block for page physics%2Fdynamics%2Fdynamicspage012 
- grade:: b-romance
 Do to be agreeable conveying oh assurance. Wicket longer admire do barton vanity itself do in it. Preferred to sportsmen it engrossed listening.  
- This is a single line in a block for page physics%2Fdynamics%2Fdynamicspage012 
### Links to other pages
[[tech/techpage018]]
