page-id:: c5a9e3a2-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: blocktags - select and exclude block level tags
- blocktags
    - tagA
    - tagD
    - not tagB
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "blocktags - select and exclude block level tags"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
(page-ref ?block "tagA")
(page-ref ?block "tagD")
)
(not (page-ref ?block "tagB"))
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "blocktags - select and exclude block level tags"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
(page-ref ?block "tagA")
(page-ref ?block "tagD")
)
(not (page-ref ?block "tagB"))
]
}
#+END_QUERY

```

### Links to other pages
[[testpage015]]
