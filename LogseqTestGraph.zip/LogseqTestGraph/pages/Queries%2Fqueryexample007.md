page-id:: 4d97df92-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: blocktags - select and exclude block level tags
- blocks
    - *
- blocktags
    - tagA
    - tagD
    - not tagB

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "blocktags - select and exclude block level tags"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
(page-ref ?block "taga")
(page-ref ?block "tagd")
)
(not (page-ref ?block "tagb"))
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "blocktags - select and exclude block level tags"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
( or 
(page-ref ?block "taga")
(page-ref ?block "tagd")
)
(not (page-ref ?block "tagb"))
]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage016]]
