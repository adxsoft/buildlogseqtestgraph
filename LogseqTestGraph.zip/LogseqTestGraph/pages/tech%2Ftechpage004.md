page-id:: c5a7aa60-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classF,classB,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Collect the fees from the club members

- TODO Post the bank letters

- LATER Clean the roof gutters

- DONE Do the Shopping

- This is a multi line block
 in page tech%2Ftechpage004 
with tag #tagE  
### Links to other pages
[[physics/dynamics/dynamicspage014]]
