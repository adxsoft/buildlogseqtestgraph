page-id:: c5a716b8-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classG,classF,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Pay the energy bill

- CANCELLED Check the water levels

- DONE Collect the fees from the club members

- LATER Check the water levels

- CANCELLED Reconcile the transaction account

- This is a single line in a block for page testpage008 
### Links to other pages
[[Queries/queryexample025]]
