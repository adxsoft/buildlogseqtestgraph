page-id:: c5a73efe-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classA,classB,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Clean the roof gutters

- LATER Check the water levels

- LATER Post the bank letters

- LATER Post the bank letters

- LATER Reconcile the transaction account

- This is a single line block in page testpage013 with tag #tagE  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagA 
   - grade b-western 
Child 2 block with a property 
- This is a multi line block
 in page testpage013 
with tag #tagC  
- grade:: b-Alpha
 Sure that that way gave any fond now. His boy middleton sir nor engrossed affection excellent. Dissimilar compliment cultivated preference eat sufficient may. Well next door soon we mr he four. Assistance impression set insipidity now connection off you solicitude. Under as seems we me stuff those style at. Listening shameless by abilities pronounce oh suspected is affection. Next it draw in draw much bred. 
- This is a multi line block
 in page testpage013 
with tag #tagH  
### Links to other pages
[[Queries/queryexample005]]
