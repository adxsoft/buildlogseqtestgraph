page-id:: 4d9567d0-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classF,classA,classF

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Dust the house furniture

- CANCELLED Post the bank letters

- CANCELLED Collect the fees from the club members

- LATER Prepare the garden bed for spring

- This is a single line in a block for page testpage003 
- This is a single line block in page testpage003 with tag #tagH  
### Links to other pages
[[Queries/queryexample036]]
