page-id:: c5a6e936-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classE,classH,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING Prepare the garden bed for spring

- DONE Clean the roof gutters

- WAITING Clean the roof gutters

- This is a single line block in page testpage003 with tag #tagF  
- This is a single line block in page testpage003 with tag #tagH  
### Links to other pages
[[tech/python/pythonpage004]]
