page-id:: c5a8984e-504d-11ed-925f-705681b02121
pagetype:: p-major
tags:: classA,classE,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Get the ingredients for the pizza

- LATER Do the Shopping

- This is a single line in a block for page tech%2Fpython%2Fpythonpage017 
- This is a single line in a block 
### Links to other pages
[[tech/techpage012]]
