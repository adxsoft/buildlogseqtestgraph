page-id:: 4d96ae6a-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classG,classA,classE

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Get the ingredients for the pizza

- TODO [[tech/techpage003]] Send email to the board

- This is a single line in a block 
- This is an indented list of items
    - Item A Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
        - Item A1 Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
        - Item A2 Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
    - Item B Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
    - Item C Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
        - Item C1 Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
    - Item D Piqued favour stairs it enable exeter as seeing. Remainder met improving but engrossed sincerity age. 
 
- This is a single line block in page tech%2Fpython%2Fpythonpage017 with tag #tagA  
- This is a multi line block
 in page tech%2Fpython%2Fpythonpage017 
with tag #tagC  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagH 
   - designation b-Alpha 
Child 2 block with a property 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagH 
   - category b-Gamma 
Child 2 block with a property 
### Links to other pages
[[Queries/queryexample007]]
