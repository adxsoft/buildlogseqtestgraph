page-id:: c5a9f662-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: find block properties in a namespace
- namespace
    - physics
- blockproperties
    - grade, "b-fiction"
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "find block properties in a namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(namespace ?page "physics")
(property ?block :grade "b-fiction")
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "find block properties in a namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(namespace ?page "physics")
(property ?block :grade "b-fiction")
]
}
#+END_QUERY

```

### Links to other pages
[[tech/python/pythonpage004]]
