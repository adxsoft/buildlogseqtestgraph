page-id:: c5a9dc04-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pages command - pages by wildcards
- pages
    - *
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - pages by wildcards"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
]
}
#+END_QUERY

```

### Links to other pages
[[physics/dynamics/dynamicspage017]]
