page-id:: 4d97be54-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pages command - select all pages
- pages
    - *

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pages command - select all pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pages command - select all pages"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
]
}
#+END_QUERY



### Links to other pages
[[tech/python/pythonpage004]]
