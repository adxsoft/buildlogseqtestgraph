page-id:: 4d97ab58-5cc6-11ed-8e96-705681b02121
pagetype:: p-basic
tags:: classA,classG,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Do the Shopping

- TODO Post the bank letters

- DONE Clean the roof gutters

- This is an indented list of items
    - Item A On consider laughter civility offended oh.
        - Item A1 On consider laughter civility offended oh.
        - Item A2 On consider laughter civility offended oh.
    - Item B On consider laughter civility offended oh.
    - Item C On consider laughter civility offended oh.
        - Item C1 On consider laughter civility offended oh.
    - Item D On consider laughter civility offended oh.
 
### Links to other pages
[[tech/python/pythonpage016]]
