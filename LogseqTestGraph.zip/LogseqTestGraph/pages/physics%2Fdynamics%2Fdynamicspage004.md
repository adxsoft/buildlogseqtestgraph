page-id:: c5a8cbac-504d-11ed-925f-705681b02121
pagetype:: p-minor
tags:: classA,classD,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Dust the house furniture

- WAITING Clean the roof gutters

- LATER Send email to the board

- WAITING Clean the roof gutters

- LATER Collect the fees from the club members

- This is a single line in a block for page physics%2Fdynamics%2Fdynamicspage004 
### Links to other pages
[[tech/python/pythonpage010]]
