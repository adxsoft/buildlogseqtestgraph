page-id:: c5a9ea50-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: select and exclude task types
- tasks
    - TODO [[physics/dynamics/dynamicspage013]]
    - not DOING
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "select and exclude task types"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/marker ?marker]
[(contains? #{"TODO [[physics/dynamics/dynamicspage013]]"} ?marker)]
(not [(contains? #{"DOING"} ?marker)])
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "select and exclude task types"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/marker ?marker]
[(contains? #{"TODO [[physics/dynamics/dynamicspage013]]"} ?marker)]
(not [(contains? #{"DOING"} ?marker)])
]
}
#+END_QUERY

```

### Links to other pages
[[physics/dynamics/dynamicspage016]]
