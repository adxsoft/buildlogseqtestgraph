page-id:: 4d984a4a-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: Page blocks only - pagetags
- pages
    - *
- pagetags
    - classC

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "Page blocks only - pagetags"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[?block :block/journal? false]
(page-tags ?block #{"classc"})
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "Page blocks only - pagetags"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[?block :block/journal? false]
(page-tags ?block #{"classc"})
]
}
#+END_QUERY



### Links to other pages
[[tech/python/pythonpage011]]
