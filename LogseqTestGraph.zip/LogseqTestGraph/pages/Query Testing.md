- Query Testing is performed using the online advanced query testing tool at https://adxsoft.github.io/logseqadvancedquerybuilder/ 
   - Follow the *how to use* instructions in the FAQ section of the online tool web page
- Paste the advanced queries you generate into a block using Cmd/Ctrl Shift V   - *Tips. Hold Shift and click the Page Title to put this page in the right panel*   - *      Examples are in the pages that start with "Query "

- Embedded Online Tool - <iframe src="https://adxsoft.github.io/logseqadvancedquerybuilder/" allow="clipboard-read; clipboard-write" style="width: 100%; height: 1000px"></iframe>

