page-id:: c5a711cc-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classC,classG,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Do the Shopping

- 
Months on ye at by esteem desire warmth former.  
- This is a single line in a block 
- This is a single line block in page testpage007 with tag #tagF  
- #tagE  On consider laughter civility offended oh. 
### Links to other pages
[[tech/techpage012]]
