page-id:: 4d957946-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classA,classH,classH

- ### Home Page
 - [[Home]]

- ### Page Contents


- DONE Clean the roof gutters

- DONE Do the Shopping

- DONE Reconcile the transaction account

- CANCELLED Do the Shopping

- LATER Post the bank letters

- LATER Get the ingredients for the pizza

- This is a parent with two children blocks
   - Child 1 block with a tag #tagG 
   - designation b-travel 
Child 2 block with a property 
### Links to other pages
[[physics/dynamics/dynamicspage018]]
