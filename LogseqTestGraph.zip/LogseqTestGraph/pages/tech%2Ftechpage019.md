page-id:: 4d9642d6-5cc6-11ed-8e96-705681b02121
pagetype:: p-minor
tags:: classB,classF,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Prepare the garden bed for spring

- LATER Do the Shopping

- CANCELLED Pay the energy bill

- LATER Get the ingredients for the pizza

- WAITING [[testpage015]] Post the bank letters

- DONE Collect the fees from the club members

- This is a single line in a block 
### Links to other pages
[[tech/python/pythonpage000]]
