page-id:: 4d9733bc-5cc6-11ed-8e96-705681b02121
pagetype:: p-minor
tags:: classG,classA,classC

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Send email to the board

- WAITING [[testpage015]] Check the water levels

- This is a single line block in page physics%2Fdynamics%2Fdynamicspage019 with tag #tagA  
- This is a parent with two children blocks
   - Child 1 block with a tag #tagA 
   - grade b-Beta 
Child 2 block with a property 
- This is a single line in a block for page physics%2Fdynamics%2Fdynamicspage019 
- This is a multi line block
 in page physics%2Fdynamics%2Fdynamicspage019 
with tag #tagC  
- This is a single line block in page physics%2Fdynamics%2Fdynamicspage019 with tag #tagF  
### Links to other pages
[[tech/python/pythonpage017]]
