page-id:: c5aa0328-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
- collapse
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
]
:collapsed? true
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
]
:collapsed? true
}
#+END_QUERY

```

### Links to other pages
[[physics/dynamics/dynamicspage019]]
