page-id:: c5a9e672-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: pagetags - page level tags
- pages
    - testpage*
- pagetags
    - p-minor
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "pagetags - page level tags"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage")]
(page-tags ?page #{"p-minor"})
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "pagetags - page level tags"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage")]
(page-tags ?page #{"p-minor"})
]
}
#+END_QUERY

```

### Links to other pages
[[testpage018]]
