page-id:: 4d980f4e-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: scheduled - find scheduled blocks in a date range
- blocks
    - *
- scheduledbetween
    - :720d-before :700d-after

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "scheduled - find scheduled blocks in a date range"]
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/scheduled ?scheduleddate]
[(>= ?scheduleddate ?startdate)]
[(<= ?scheduleddate ?enddate)]
]
:inputs [:720d-before :700d-after]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "scheduled - find scheduled blocks in a date range"]
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/scheduled ?scheduleddate]
[(>= ?scheduleddate ?startdate)]
[(<= ?scheduleddate ?enddate)]
]
:inputs [:720d-before :700d-after]
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage011]]
