page-id:: c5a9f946-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
- scheduledbetween
    - :120d-before :90d-after
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/scheduled ?scheduleddate]
[(>= ?scheduleddate ?startdate)]
[(<= ?scheduleddate ?enddate)]
]
:inputs [:120d-before :90d-after]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/scheduled ?scheduleddate]
[(>= ?scheduleddate ?startdate)]
[(<= ?scheduleddate ?enddate)]
]
:inputs [:120d-before :90d-after]
}
#+END_QUERY

```

### Links to other pages
[[tech/techpage010]]
