page-id:: c5a9f4dc-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: only search in specific namespace
- namespace
    - physics
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "only search in specific namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(namespace ?page "physics")
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "only search in specific namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
(namespace ?page "physics")
]
}
#+END_QUERY

```

### Links to other pages
[[Queries/queryexample026]]
