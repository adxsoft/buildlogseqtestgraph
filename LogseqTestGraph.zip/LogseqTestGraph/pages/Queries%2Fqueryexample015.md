page-id:: 4d98029c-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: only search pages in specific namespace
- pages
    - *
- namespace
    - physics

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "only search pages in specific namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
(namespace ?block "physics")
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "only search pages in specific namespace"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
(namespace ?block "physics")
]
}
#+END_QUERY



### Links to other pages
[[physics/dynamics/dynamicspage008]]
