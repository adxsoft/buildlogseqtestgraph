page-id:: c5a98ede-504d-11ed-925f-705681b02121
pagetype:: p-advanced
tags:: classH,classC,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[physics/dynamics/dynamicspage013]] Check the water levels

- CANCELLED Reconcile the transaction account

- CANCELLED Pay the energy bill

- CANCELLED Pay the energy bill

- LATER Send email to the board

- WAITING Clean the roof gutters

- This is a single line block in page physics%2Ffluids%2Ffluidspage011 with tag #tagE  
### Links to other pages
[[tech/python/pythonpage009]]
