page-id:: c5a9fd10-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
- deadlinebetween
    - :120d-before :30d-after
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/deadline ?deadlinedate]
[(>= ?deadlinedate ?startdate)]
[(<= ?deadlinedate ?enddate)]
]
:inputs [:120d-before :30d-after]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:in $ ?startdate ?enddate
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/deadline ?deadlinedate]
[(>= ?deadlinedate ?startdate)]
[(<= ?deadlinedate ?enddate)]
]
:inputs [:120d-before :30d-after]
}
#+END_QUERY

```

### Links to other pages
[[physics/dynamics/dynamicspage011]]
