page-id:: 4d982cf4-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: expand results
- pages
    - testpage00*
- expand

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "expand results"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
:collapsed? false
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "expand results"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
:collapsed? false
}
#+END_QUERY



### Links to other pages
[[tech/techpage002]]
