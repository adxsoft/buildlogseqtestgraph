page-id:: c5a8feec-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classE,classA,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Get the ingredients for the pizza

- CANCELLED Do the Shopping

- TODO Reconcile the transaction account

- TODO Collect the fees from the club members

- LATER Check the water levels

- TODO Post the bank letters

- This is a parent with two children blocks
   - Child 1 block with a tag #tagE 
   - designation b-Alpha 
Child 2 block with a property 
- This is a single line block in page physics%2Fdynamics%2Fdynamicspage011 with tag #tagC  
### Links to other pages
[[Queries/queryexample014]]
