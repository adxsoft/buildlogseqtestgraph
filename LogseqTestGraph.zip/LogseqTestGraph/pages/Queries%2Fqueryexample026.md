page-id:: 4d983118-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: show breadcrumbs
- pages
    - testpage00*
- showbreadcrumb

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "show breadcrumbs"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
:breadcrumb-show? true
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "show breadcrumbs"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[(clojure.string/starts-with? ?pagename "testpage00")]
]
:breadcrumb-show? true
}
#+END_QUERY



### Links to other pages
[[physics/fluids/fluidspage009]]
