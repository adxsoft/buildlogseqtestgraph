page-id:: 4d981bd8-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: find journals
- pages
    - *
- journalonly

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "find journals"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[?block :block/journal? true]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "find journals"]
:query [:find (pull ?block [*])
:where
[?block :block/name ?pagename]
[?block :block/journal? true]
]
}
#+END_QUERY



### Links to other pages
[[testpage012]]
