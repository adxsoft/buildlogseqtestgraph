page-id:: c5a9feaa-504d-11ed-925f-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
- journalonly
```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?page :block/journal? true]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?page :block/journal? true]
]
}
#+END_QUERY

```

### Links to other pages
[[tech/techpage017]]
