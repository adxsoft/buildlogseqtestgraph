- [[Home]]
- ## Graph Folder: 
  - /Users/allandavies/Desktop/LogseqTestGraph/

- ## Pages Groups Generated

  - Test Pages
    - namespace: none
    - page prefix: testpage
    - no of pages: 20
  - tech namespace Pages
    - namespace: tech/
    - page prefix: techpage
    - no of pages: 20
  - tech/python namespace Pages
    - namespace: tech/python/
    - page prefix: pythonpage
    - no of pages: 20
  - physics/dynamics pages
    - namespace: physics/dynamics/
    - page prefix: dynamicspage
    - no of pages: 20
  - physics/fluids pages
    - namespace: physics/fluids/
    - page prefix: fluidspage
    - no of pages: 20

- ## Journals Generated
  - from date: 2020_01_01
  - to date: 2023_12_31
  - no journals: 50
  - max increment in days: 45

## Query Examples Pages Generated
 - no of examples: 28
 

