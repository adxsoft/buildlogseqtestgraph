page-id:: c5a7b26c-504d-11ed-925f-705681b02121
pagetype:: p-advanced
tags:: classE,classG,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- TODO [[physics/dynamics/dynamicspage013]] Get the ingredients for the pizza

- DONE Pay the energy bill

- This is a parent with two children blocks
   - Child 1 block with a tag #tagD 
   - designation b-Alpha 
Child 2 block with a property 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagG 
   - category b-thriller 
Child 2 block with a property 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagH 
   - designation b-non-fiction 
Child 2 block with a property 
- This is a single line in a block for page tech%2Ftechpage006 
- This is a single line in a block 
- #tagF  Ignorant saw her her drawings marriage laughter. Case oh an that or away sigh do here upon. Acuteness you exquisite ourselves now end forfeited. Enquire ye without it garrets up himself. Interest our nor received followed was. Cultivated an up solicitude mr unpleasant. 
### Links to other pages
[[Queries/queryexample023]]
