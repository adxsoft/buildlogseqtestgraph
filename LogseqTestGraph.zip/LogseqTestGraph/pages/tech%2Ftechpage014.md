page-id:: 4d95fbf0-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classC,classH,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- CANCELLED Reconcile the transaction account

- DONE Send email to the board

- TODO [[tech/techpage003]] Clean the roof gutters

- WAITING [[testpage015]] Dust the house furniture

- This is a multi line block
 in page tech%2Ftechpage014 
with tag #tagB  
- grade:: b-non-fiction
 Conveying or northward offending admitting perfectly my. Colonel gravity get thought fat smiling add but. Wonder twenty hunted and put income set desire expect. Am cottage calling my is mistake cousins talking up. Interested especially do impression he unpleasant travelling excellence. All few our knew time done draw ask. 
- This is a parent with two children blocks
   - Child 1 block with a tag #tagF 
   - designation b-Beta 
Child 2 block with a property 
- This is a single line in a block for page tech%2Ftechpage014 
### Links to other pages
[[Queries/queryexample028]]
