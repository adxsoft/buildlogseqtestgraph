page-id:: c5a85f32-504d-11ed-925f-705681b02121
pagetype:: p-basic
tags:: classC,classA,classA

- ### Home Page
 - [[Home]]

- ### Page Contents


- WAITING Collect the fees from the club members

- This is a single line in a block 
### Links to other pages
[[physics/dynamics/dynamicspage019]]
