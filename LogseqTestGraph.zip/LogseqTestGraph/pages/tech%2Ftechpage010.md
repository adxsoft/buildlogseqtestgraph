page-id:: 4d95e9ee-5cc6-11ed-8e96-705681b02121
pagetype:: p-advanced
tags:: classG,classD,classG

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Collect the fees from the club members

- LATER Send email to the board

- LATER Prepare the garden bed for spring

- This is a single line in a block for page tech%2Ftechpage010 
- This is a single line block in page tech%2Ftechpage010 with tag #tagE  
### Links to other pages
[[testpage016]]
