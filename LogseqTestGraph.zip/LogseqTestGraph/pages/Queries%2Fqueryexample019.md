page-id:: 4d98137c-5cc6-11ed-8e96-705681b02121
pagetype:: query
[[Home]]
- Query Commands
    - ```
title: find blocks with deadlines
- blocks
    - *
- deadline

```

- Generated Query
    - ```clojure

#+BEGIN_QUERY
{
:title [:b "find blocks with deadlines"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/deadline ?deadlinedate]
]
}
#+END_QUERY

```

- Query Results

    - #+BEGIN_QUERY
{
:title [:b "find blocks with deadlines"]
:query [:find (pull ?block [*])
:where
[?block :block/content ?blockcontent]
[?block :block/page ?page]
[?page :block/name ?pagename]
[?block :block/deadline ?deadlinedate]
]
}
#+END_QUERY



### Links to other pages
[[tech/python/pythonpage003]]
