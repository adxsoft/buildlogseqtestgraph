page-id:: 4d969132-5cc6-11ed-8e96-705681b02121
pagetype:: p-major
tags:: classG,classD,classB

- ### Home Page
 - [[Home]]

- ### Page Contents


- LATER Clean the roof gutters

- TODO Clean the roof gutters

- This is a single line block in page tech%2Fpython%2Fpythonpage010 with tag #tagB  
### Links to other pages
[[physics/fluids/fluidspage018]]
